// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v4.view;


// Referenced classes of package android.support.v4.view:
//            KeyEventCompat, KeyEventCompatHoneycomb

static class I extends I
{

    public boolean metaStateHasModifiers(int i, int j)
    {
        return KeyEventCompatHoneycomb.metaStateHasModifiers(i, j);
    }

    public boolean metaStateHasNoModifiers(int i)
    {
        return KeyEventCompatHoneycomb.metaStateHasNoModifiers(i);
    }

    public int normalizeMetaState(int i)
    {
        return KeyEventCompatHoneycomb.normalizeMetaState(i);
    }

    I()
    {
    }
}
