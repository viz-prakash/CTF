// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package picoapp453.picoctf.com.picoapp;


// Referenced classes of package picoapp453.picoctf.com.picoapp:
//            R

public static final class 
{

    public static final int action_bar = 0x7f07001c;
    public static final int action_bar_activity_content = 0x7f070014;
    public static final int action_bar_container = 0x7f07001b;
    public static final int action_bar_overlay_layout = 0x7f07001f;
    public static final int action_bar_root = 0x7f07001a;
    public static final int action_bar_subtitle = 0x7f070023;
    public static final int action_bar_title = 0x7f070022;
    public static final int action_context_bar = 0x7f07001d;
    public static final int action_menu_divider = 0x7f070015;
    public static final int action_menu_presenter = 0x7f070016;
    public static final int action_mode_close_button = 0x7f070024;
    public static final int action_settings = 0x7f07003d;
    public static final int activity_chooser_view_content = 0x7f070025;
    public static final int always = 0x7f07000f;
    public static final int beginning = 0x7f07000a;
    public static final int button_click = 0x7f07003c;
    public static final int checkbox = 0x7f07002d;
    public static final int collapseActionView = 0x7f070011;
    public static final int default_activity_button = 0x7f070028;
    public static final int dialog = 0x7f070012;
    public static final int disableHome = 0x7f070008;
    public static final int dropdown = 0x7f070013;
    public static final int edit_query = 0x7f070030;
    public static final int end = 0x7f07000c;
    public static final int expand_activities_button = 0x7f070026;
    public static final int expanded_menu = 0x7f07002c;
    public static final int home = 0x7f070017;
    public static final int homeAsUp = 0x7f070005;
    public static final int icon = 0x7f07002a;
    public static final int ifRoom = 0x7f07000e;
    public static final int image = 0x7f070027;
    public static final int listMode = 0x7f070001;
    public static final int list_item = 0x7f070029;
    public static final int middle = 0x7f07000b;
    public static final int never = 0x7f07000d;
    public static final int none = 0x7f070009;
    public static final int normal = 0x7f070000;
    public static final int progress_circular = 0x7f070018;
    public static final int progress_horizontal = 0x7f070019;
    public static final int radio = 0x7f07002f;
    public static final int search_badge = 0x7f070032;
    public static final int search_bar = 0x7f070031;
    public static final int search_button = 0x7f070033;
    public static final int search_close_btn = 0x7f070038;
    public static final int search_edit_frame = 0x7f070034;
    public static final int search_go_btn = 0x7f07003a;
    public static final int search_mag_icon = 0x7f070035;
    public static final int search_plate = 0x7f070036;
    public static final int search_src_text = 0x7f070037;
    public static final int search_voice_btn = 0x7f07003b;
    public static final int shortcut = 0x7f07002e;
    public static final int showCustom = 0x7f070007;
    public static final int showHome = 0x7f070004;
    public static final int showTitle = 0x7f070006;
    public static final int split_action_bar = 0x7f07001e;
    public static final int submit_area = 0x7f070039;
    public static final int tabMode = 0x7f070002;
    public static final int title = 0x7f07002b;
    public static final int top_action_bar = 0x7f070020;
    public static final int up = 0x7f070021;
    public static final int useLogo = 0x7f070003;
    public static final int withText = 0x7f070010;

    public ()
    {
    }
}
