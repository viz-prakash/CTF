// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package picoapp453.picoctf.com.picoapp;


// Referenced classes of package picoapp453.picoctf.com.picoapp:
//            R

public static final class 
{

    public static final int abc_search_url_text_holo = 0x7f060003;
    public static final int abc_search_url_text_normal = 0x7f060000;
    public static final int abc_search_url_text_pressed = 0x7f060001;
    public static final int abc_search_url_text_selected = 0x7f060002;

    public ()
    {
    }
}
