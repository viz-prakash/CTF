// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package picoapp453.picoctf.com.picoapp;


public final class R
{
    public static final class anim
    {

        public static final int abc_fade_in = 0x7f040000;
        public static final int abc_fade_out = 0x7f040001;
        public static final int abc_slide_in_bottom = 0x7f040002;
        public static final int abc_slide_in_top = 0x7f040003;
        public static final int abc_slide_out_bottom = 0x7f040004;
        public static final int abc_slide_out_top = 0x7f040005;

        public anim()
        {
        }
    }

    public static final class attr
    {

        public static final int actionBarDivider = 0x7f010000;
        public static final int actionBarItemBackground = 0x7f010001;
        public static final int actionBarSize = 0x7f010002;
        public static final int actionBarSplitStyle = 0x7f010003;
        public static final int actionBarStyle = 0x7f010004;
        public static final int actionBarTabBarStyle = 0x7f010005;
        public static final int actionBarTabStyle = 0x7f010006;
        public static final int actionBarTabTextStyle = 0x7f010007;
        public static final int actionBarWidgetTheme = 0x7f010008;
        public static final int actionButtonStyle = 0x7f010009;
        public static final int actionDropDownStyle = 0x7f010066;
        public static final int actionLayout = 0x7f01005d;
        public static final int actionMenuTextAppearance = 0x7f01000a;
        public static final int actionMenuTextColor = 0x7f01000b;
        public static final int actionModeBackground = 0x7f01000c;
        public static final int actionModeCloseButtonStyle = 0x7f01000d;
        public static final int actionModeCloseDrawable = 0x7f01000e;
        public static final int actionModeCopyDrawable = 0x7f01000f;
        public static final int actionModeCutDrawable = 0x7f010010;
        public static final int actionModeFindDrawable = 0x7f010011;
        public static final int actionModePasteDrawable = 0x7f010012;
        public static final int actionModePopupWindowStyle = 0x7f010013;
        public static final int actionModeSelectAllDrawable = 0x7f010014;
        public static final int actionModeShareDrawable = 0x7f010015;
        public static final int actionModeSplitBackground = 0x7f010016;
        public static final int actionModeStyle = 0x7f010017;
        public static final int actionModeWebSearchDrawable = 0x7f010018;
        public static final int actionOverflowButtonStyle = 0x7f010019;
        public static final int actionProviderClass = 0x7f01005f;
        public static final int actionViewClass = 0x7f01005e;
        public static final int activityChooserViewStyle = 0x7f01001a;
        public static final int background = 0x7f010047;
        public static final int backgroundSplit = 0x7f010049;
        public static final int backgroundStacked = 0x7f010048;
        public static final int buttonBarButtonStyle = 0x7f01001b;
        public static final int buttonBarStyle = 0x7f01001c;
        public static final int customNavigationLayout = 0x7f01004a;
        public static final int disableChildrenWhenDisabled = 0x7f010065;
        public static final int displayOptions = 0x7f010040;
        public static final int divider = 0x7f010046;
        public static final int dividerHorizontal = 0x7f01001d;
        public static final int dividerPadding = 0x7f01005b;
        public static final int dividerVertical = 0x7f01001e;
        public static final int dropDownListViewStyle = 0x7f01001f;
        public static final int dropdownListPreferredItemHeight = 0x7f010067;
        public static final int expandActivityOverflowButtonDrawable = 0x7f010058;
        public static final int height = 0x7f010020;
        public static final int homeAsUpIndicator = 0x7f010021;
        public static final int homeLayout = 0x7f01004b;
        public static final int icon = 0x7f010044;
        public static final int iconifiedByDefault = 0x7f010060;
        public static final int indeterminateProgressStyle = 0x7f01004d;
        public static final int initialActivityCount = 0x7f010057;
        public static final int isLightTheme = 0x7f010022;
        public static final int itemPadding = 0x7f01004f;
        public static final int listChoiceBackgroundIndicator = 0x7f01006b;
        public static final int listPopupWindowStyle = 0x7f010023;
        public static final int listPreferredItemHeight = 0x7f010024;
        public static final int listPreferredItemHeightLarge = 0x7f010025;
        public static final int listPreferredItemHeightSmall = 0x7f010026;
        public static final int listPreferredItemPaddingLeft = 0x7f010027;
        public static final int listPreferredItemPaddingRight = 0x7f010028;
        public static final int logo = 0x7f010045;
        public static final int navigationMode = 0x7f01003f;
        public static final int paddingEnd = 0x7f01006d;
        public static final int paddingStart = 0x7f01006c;
        public static final int panelMenuListTheme = 0x7f01006a;
        public static final int panelMenuListWidth = 0x7f010069;
        public static final int popupMenuStyle = 0x7f010068;
        public static final int popupPromptView = 0x7f010064;
        public static final int progressBarPadding = 0x7f01004e;
        public static final int progressBarStyle = 0x7f01004c;
        public static final int prompt = 0x7f010062;
        public static final int queryHint = 0x7f010061;
        public static final int searchDropdownBackground = 0x7f010029;
        public static final int searchResultListItemHeight = 0x7f01002a;
        public static final int searchViewAutoCompleteTextView = 0x7f01002b;
        public static final int searchViewCloseIcon = 0x7f01002c;
        public static final int searchViewEditQuery = 0x7f01002d;
        public static final int searchViewEditQueryBackground = 0x7f01002e;
        public static final int searchViewGoIcon = 0x7f01002f;
        public static final int searchViewSearchIcon = 0x7f010030;
        public static final int searchViewTextField = 0x7f010031;
        public static final int searchViewTextFieldRight = 0x7f010032;
        public static final int searchViewVoiceIcon = 0x7f010033;
        public static final int selectableItemBackground = 0x7f010034;
        public static final int showAsAction = 0x7f01005c;
        public static final int showDividers = 0x7f01005a;
        public static final int spinnerDropDownItemStyle = 0x7f010035;
        public static final int spinnerMode = 0x7f010063;
        public static final int spinnerStyle = 0x7f010036;
        public static final int subtitle = 0x7f010041;
        public static final int subtitleTextStyle = 0x7f010043;
        public static final int textAllCaps = 0x7f010059;
        public static final int textAppearanceLargePopupMenu = 0x7f010037;
        public static final int textAppearanceListItem = 0x7f010038;
        public static final int textAppearanceListItemSmall = 0x7f010039;
        public static final int textAppearanceSearchResultSubtitle = 0x7f01003a;
        public static final int textAppearanceSearchResultTitle = 0x7f01003b;
        public static final int textAppearanceSmallPopupMenu = 0x7f01003c;
        public static final int textColorSearchUrl = 0x7f01003d;
        public static final int title = 0x7f01003e;
        public static final int titleTextStyle = 0x7f010042;
        public static final int windowActionBar = 0x7f010050;
        public static final int windowActionBarOverlay = 0x7f010051;
        public static final int windowFixedHeightMajor = 0x7f010056;
        public static final int windowFixedHeightMinor = 0x7f010054;
        public static final int windowFixedWidthMajor = 0x7f010053;
        public static final int windowFixedWidthMinor = 0x7f010055;
        public static final int windowSplitActionBar = 0x7f010052;

        public attr()
        {
        }
    }

    public static final class bool
    {

        public static final int abc_action_bar_embed_tabs_pre_jb = 0x7f050000;
        public static final int abc_action_bar_expanded_action_views_exclusive = 0x7f050001;
        public static final int abc_config_actionMenuItemAllCaps = 0x7f050002;
        public static final int abc_config_allowActionMenuItemTextWithIcon = 0x7f050003;
        public static final int abc_config_showMenuShortcutsWhenKeyboardPresent = 0x7f050004;
        public static final int abc_split_action_bar_is_narrow = 0x7f050005;

        public bool()
        {
        }
    }

    public static final class color
    {

        public static final int abc_search_url_text_holo = 0x7f060003;
        public static final int abc_search_url_text_normal = 0x7f060000;
        public static final int abc_search_url_text_pressed = 0x7f060001;
        public static final int abc_search_url_text_selected = 0x7f060002;

        public color()
        {
        }
    }

    public static final class dimen
    {

        public static final int abc_action_bar_default_height = 0x7f080000;
        public static final int abc_action_bar_icon_vertical_padding = 0x7f080001;
        public static final int abc_action_bar_progress_bar_size = 0x7f080002;
        public static final int abc_action_bar_stacked_max_height = 0x7f080003;
        public static final int abc_action_bar_stacked_tab_max_width = 0x7f080004;
        public static final int abc_action_bar_subtitle_bottom_margin = 0x7f080005;
        public static final int abc_action_bar_subtitle_text_size = 0x7f080006;
        public static final int abc_action_bar_subtitle_top_margin = 0x7f080007;
        public static final int abc_action_bar_title_text_size = 0x7f080008;
        public static final int abc_action_button_min_width = 0x7f080009;
        public static final int abc_config_prefDialogWidth = 0x7f08000a;
        public static final int abc_dropdownitem_icon_width = 0x7f08000b;
        public static final int abc_dropdownitem_text_padding_left = 0x7f08000c;
        public static final int abc_dropdownitem_text_padding_right = 0x7f08000d;
        public static final int abc_panel_menu_list_width = 0x7f08000e;
        public static final int abc_search_view_preferred_width = 0x7f08000f;
        public static final int abc_search_view_text_min_width = 0x7f080010;
        public static final int activity_horizontal_margin = 0x7f080011;
        public static final int activity_vertical_margin = 0x7f080012;
        public static final int dialog_fixed_height_major = 0x7f080013;
        public static final int dialog_fixed_height_minor = 0x7f080014;
        public static final int dialog_fixed_width_major = 0x7f080015;
        public static final int dialog_fixed_width_minor = 0x7f080016;

        public dimen()
        {
        }
    }

    public static final class drawable
    {

        public static final int abc_ab_bottom_solid_dark_holo = 0x7f020000;
        public static final int abc_ab_bottom_solid_light_holo = 0x7f020001;
        public static final int abc_ab_bottom_transparent_dark_holo = 0x7f020002;
        public static final int abc_ab_bottom_transparent_light_holo = 0x7f020003;
        public static final int abc_ab_share_pack_holo_dark = 0x7f020004;
        public static final int abc_ab_share_pack_holo_light = 0x7f020005;
        public static final int abc_ab_solid_dark_holo = 0x7f020006;
        public static final int abc_ab_solid_light_holo = 0x7f020007;
        public static final int abc_ab_stacked_solid_dark_holo = 0x7f020008;
        public static final int abc_ab_stacked_solid_light_holo = 0x7f020009;
        public static final int abc_ab_stacked_transparent_dark_holo = 0x7f02000a;
        public static final int abc_ab_stacked_transparent_light_holo = 0x7f02000b;
        public static final int abc_ab_transparent_dark_holo = 0x7f02000c;
        public static final int abc_ab_transparent_light_holo = 0x7f02000d;
        public static final int abc_cab_background_bottom_holo_dark = 0x7f02000e;
        public static final int abc_cab_background_bottom_holo_light = 0x7f02000f;
        public static final int abc_cab_background_top_holo_dark = 0x7f020010;
        public static final int abc_cab_background_top_holo_light = 0x7f020011;
        public static final int abc_ic_ab_back_holo_dark = 0x7f020012;
        public static final int abc_ic_ab_back_holo_light = 0x7f020013;
        public static final int abc_ic_cab_done_holo_dark = 0x7f020014;
        public static final int abc_ic_cab_done_holo_light = 0x7f020015;
        public static final int abc_ic_clear = 0x7f020016;
        public static final int abc_ic_clear_disabled = 0x7f020017;
        public static final int abc_ic_clear_holo_light = 0x7f020018;
        public static final int abc_ic_clear_normal = 0x7f020019;
        public static final int abc_ic_clear_search_api_disabled_holo_light = 0x7f02001a;
        public static final int abc_ic_clear_search_api_holo_light = 0x7f02001b;
        public static final int abc_ic_commit_search_api_holo_dark = 0x7f02001c;
        public static final int abc_ic_commit_search_api_holo_light = 0x7f02001d;
        public static final int abc_ic_go = 0x7f02001e;
        public static final int abc_ic_go_search_api_holo_light = 0x7f02001f;
        public static final int abc_ic_menu_moreoverflow_normal_holo_dark = 0x7f020020;
        public static final int abc_ic_menu_moreoverflow_normal_holo_light = 0x7f020021;
        public static final int abc_ic_menu_share_holo_dark = 0x7f020022;
        public static final int abc_ic_menu_share_holo_light = 0x7f020023;
        public static final int abc_ic_search = 0x7f020024;
        public static final int abc_ic_search_api_holo_light = 0x7f020025;
        public static final int abc_ic_voice_search = 0x7f020026;
        public static final int abc_ic_voice_search_api_holo_light = 0x7f020027;
        public static final int abc_item_background_holo_dark = 0x7f020028;
        public static final int abc_item_background_holo_light = 0x7f020029;
        public static final int abc_list_divider_holo_dark = 0x7f02002a;
        public static final int abc_list_divider_holo_light = 0x7f02002b;
        public static final int abc_list_focused_holo = 0x7f02002c;
        public static final int abc_list_longpressed_holo = 0x7f02002d;
        public static final int abc_list_pressed_holo_dark = 0x7f02002e;
        public static final int abc_list_pressed_holo_light = 0x7f02002f;
        public static final int abc_list_selector_background_transition_holo_dark = 0x7f020030;
        public static final int abc_list_selector_background_transition_holo_light = 0x7f020031;
        public static final int abc_list_selector_disabled_holo_dark = 0x7f020032;
        public static final int abc_list_selector_disabled_holo_light = 0x7f020033;
        public static final int abc_list_selector_holo_dark = 0x7f020034;
        public static final int abc_list_selector_holo_light = 0x7f020035;
        public static final int abc_menu_dropdown_panel_holo_dark = 0x7f020036;
        public static final int abc_menu_dropdown_panel_holo_light = 0x7f020037;
        public static final int abc_menu_hardkey_panel_holo_dark = 0x7f020038;
        public static final int abc_menu_hardkey_panel_holo_light = 0x7f020039;
        public static final int abc_search_dropdown_dark = 0x7f02003a;
        public static final int abc_search_dropdown_light = 0x7f02003b;
        public static final int abc_spinner_ab_default_holo_dark = 0x7f02003c;
        public static final int abc_spinner_ab_default_holo_light = 0x7f02003d;
        public static final int abc_spinner_ab_disabled_holo_dark = 0x7f02003e;
        public static final int abc_spinner_ab_disabled_holo_light = 0x7f02003f;
        public static final int abc_spinner_ab_focused_holo_dark = 0x7f020040;
        public static final int abc_spinner_ab_focused_holo_light = 0x7f020041;
        public static final int abc_spinner_ab_holo_dark = 0x7f020042;
        public static final int abc_spinner_ab_holo_light = 0x7f020043;
        public static final int abc_spinner_ab_pressed_holo_dark = 0x7f020044;
        public static final int abc_spinner_ab_pressed_holo_light = 0x7f020045;
        public static final int abc_tab_indicator_ab_holo = 0x7f020046;
        public static final int abc_tab_selected_focused_holo = 0x7f020047;
        public static final int abc_tab_selected_holo = 0x7f020048;
        public static final int abc_tab_selected_pressed_holo = 0x7f020049;
        public static final int abc_tab_unselected_pressed_holo = 0x7f02004a;
        public static final int abc_textfield_search_default_holo_dark = 0x7f02004b;
        public static final int abc_textfield_search_default_holo_light = 0x7f02004c;
        public static final int abc_textfield_search_right_default_holo_dark = 0x7f02004d;
        public static final int abc_textfield_search_right_default_holo_light = 0x7f02004e;
        public static final int abc_textfield_search_right_selected_holo_dark = 0x7f02004f;
        public static final int abc_textfield_search_right_selected_holo_light = 0x7f020050;
        public static final int abc_textfield_search_selected_holo_dark = 0x7f020051;
        public static final int abc_textfield_search_selected_holo_light = 0x7f020052;
        public static final int abc_textfield_searchview_holo_dark = 0x7f020053;
        public static final int abc_textfield_searchview_holo_light = 0x7f020054;
        public static final int abc_textfield_searchview_right_holo_dark = 0x7f020055;
        public static final int abc_textfield_searchview_right_holo_light = 0x7f020056;
        public static final int ic_launcher = 0x7f020057;

        public drawable()
        {
        }
    }

    public static final class id
    {

        public static final int action_bar = 0x7f07001c;
        public static final int action_bar_activity_content = 0x7f070014;
        public static final int action_bar_container = 0x7f07001b;
        public static final int action_bar_overlay_layout = 0x7f07001f;
        public static final int action_bar_root = 0x7f07001a;
        public static final int action_bar_subtitle = 0x7f070023;
        public static final int action_bar_title = 0x7f070022;
        public static final int action_context_bar = 0x7f07001d;
        public static final int action_menu_divider = 0x7f070015;
        public static final int action_menu_presenter = 0x7f070016;
        public static final int action_mode_close_button = 0x7f070024;
        public static final int action_settings = 0x7f07003d;
        public static final int activity_chooser_view_content = 0x7f070025;
        public static final int always = 0x7f07000f;
        public static final int beginning = 0x7f07000a;
        public static final int button_click = 0x7f07003c;
        public static final int checkbox = 0x7f07002d;
        public static final int collapseActionView = 0x7f070011;
        public static final int default_activity_button = 0x7f070028;
        public static final int dialog = 0x7f070012;
        public static final int disableHome = 0x7f070008;
        public static final int dropdown = 0x7f070013;
        public static final int edit_query = 0x7f070030;
        public static final int end = 0x7f07000c;
        public static final int expand_activities_button = 0x7f070026;
        public static final int expanded_menu = 0x7f07002c;
        public static final int home = 0x7f070017;
        public static final int homeAsUp = 0x7f070005;
        public static final int icon = 0x7f07002a;
        public static final int ifRoom = 0x7f07000e;
        public static final int image = 0x7f070027;
        public static final int listMode = 0x7f070001;
        public static final int list_item = 0x7f070029;
        public static final int middle = 0x7f07000b;
        public static final int never = 0x7f07000d;
        public static final int none = 0x7f070009;
        public static final int normal = 0x7f070000;
        public static final int progress_circular = 0x7f070018;
        public static final int progress_horizontal = 0x7f070019;
        public static final int radio = 0x7f07002f;
        public static final int search_badge = 0x7f070032;
        public static final int search_bar = 0x7f070031;
        public static final int search_button = 0x7f070033;
        public static final int search_close_btn = 0x7f070038;
        public static final int search_edit_frame = 0x7f070034;
        public static final int search_go_btn = 0x7f07003a;
        public static final int search_mag_icon = 0x7f070035;
        public static final int search_plate = 0x7f070036;
        public static final int search_src_text = 0x7f070037;
        public static final int search_voice_btn = 0x7f07003b;
        public static final int shortcut = 0x7f07002e;
        public static final int showCustom = 0x7f070007;
        public static final int showHome = 0x7f070004;
        public static final int showTitle = 0x7f070006;
        public static final int split_action_bar = 0x7f07001e;
        public static final int submit_area = 0x7f070039;
        public static final int tabMode = 0x7f070002;
        public static final int title = 0x7f07002b;
        public static final int top_action_bar = 0x7f070020;
        public static final int up = 0x7f070021;
        public static final int useLogo = 0x7f070003;
        public static final int withText = 0x7f070010;

        public id()
        {
        }
    }

    public static final class integer
    {

        public static final int abc_max_action_buttons = 0x7f090000;

        public integer()
        {
        }
    }

    public static final class layout
    {

        public static final int abc_action_bar_decor = 0x7f030000;
        public static final int abc_action_bar_decor_include = 0x7f030001;
        public static final int abc_action_bar_decor_overlay = 0x7f030002;
        public static final int abc_action_bar_home = 0x7f030003;
        public static final int abc_action_bar_tab = 0x7f030004;
        public static final int abc_action_bar_tabbar = 0x7f030005;
        public static final int abc_action_bar_title_item = 0x7f030006;
        public static final int abc_action_bar_view_list_nav_layout = 0x7f030007;
        public static final int abc_action_menu_item_layout = 0x7f030008;
        public static final int abc_action_menu_layout = 0x7f030009;
        public static final int abc_action_mode_bar = 0x7f03000a;
        public static final int abc_action_mode_close_item = 0x7f03000b;
        public static final int abc_activity_chooser_view = 0x7f03000c;
        public static final int abc_activity_chooser_view_include = 0x7f03000d;
        public static final int abc_activity_chooser_view_list_item = 0x7f03000e;
        public static final int abc_expanded_menu_layout = 0x7f03000f;
        public static final int abc_list_menu_item_checkbox = 0x7f030010;
        public static final int abc_list_menu_item_icon = 0x7f030011;
        public static final int abc_list_menu_item_layout = 0x7f030012;
        public static final int abc_list_menu_item_radio = 0x7f030013;
        public static final int abc_popup_menu_item_layout = 0x7f030014;
        public static final int abc_search_dropdown_item_icons_2line = 0x7f030015;
        public static final int abc_search_view = 0x7f030016;
        public static final int abc_simple_decor = 0x7f030017;
        public static final int activity_my = 0x7f030018;
        public static final int support_simple_spinner_dropdown_item = 0x7f030019;

        public layout()
        {
        }
    }

    public static final class menu
    {

        public static final int my = 0x7f0c0000;

        public menu()
        {
        }
    }

    public static final class string
    {

        public static final int abc_action_bar_home_description = 0x7f0a0000;
        public static final int abc_action_bar_up_description = 0x7f0a0001;
        public static final int abc_action_menu_overflow_description = 0x7f0a0002;
        public static final int abc_action_mode_done = 0x7f0a0003;
        public static final int abc_activity_chooser_view_see_all = 0x7f0a0004;
        public static final int abc_activitychooserview_choose_application = 0x7f0a0005;
        public static final int abc_searchview_description_clear = 0x7f0a0006;
        public static final int abc_searchview_description_query = 0x7f0a0007;
        public static final int abc_searchview_description_search = 0x7f0a0008;
        public static final int abc_searchview_description_submit = 0x7f0a0009;
        public static final int abc_searchview_description_voice = 0x7f0a000a;
        public static final int abc_shareactionprovider_share_with = 0x7f0a000b;
        public static final int abc_shareactionprovider_share_with_application = 0x7f0a000c;
        public static final int action_settings = 0x7f0a000d;
        public static final int app_name = 0x7f0a000e;
        public static final int button_name = 0x7f0a000f;

        public string()
        {
        }
    }

    public static final class style
    {

        public static final int AppTheme = 0x7f0b0000;
        public static final int TextAppearance_AppCompat_Base_CompactMenu_Dialog = 0x7f0b0001;
        public static final int TextAppearance_AppCompat_Base_SearchResult = 0x7f0b0002;
        public static final int TextAppearance_AppCompat_Base_SearchResult_Subtitle = 0x7f0b0003;
        public static final int TextAppearance_AppCompat_Base_SearchResult_Title = 0x7f0b0004;
        public static final int TextAppearance_AppCompat_Base_Widget_PopupMenu_Large = 0x7f0b0005;
        public static final int TextAppearance_AppCompat_Base_Widget_PopupMenu_Small = 0x7f0b0006;
        public static final int TextAppearance_AppCompat_Light_Base_SearchResult = 0x7f0b0007;
        public static final int TextAppearance_AppCompat_Light_Base_SearchResult_Subtitle = 0x7f0b0008;
        public static final int TextAppearance_AppCompat_Light_Base_SearchResult_Title = 0x7f0b0009;
        public static final int TextAppearance_AppCompat_Light_Base_Widget_PopupMenu_Large = 0x7f0b000a;
        public static final int TextAppearance_AppCompat_Light_Base_Widget_PopupMenu_Small = 0x7f0b000b;
        public static final int TextAppearance_AppCompat_Light_SearchResult_Subtitle = 0x7f0b000c;
        public static final int TextAppearance_AppCompat_Light_SearchResult_Title = 0x7f0b000d;
        public static final int TextAppearance_AppCompat_Light_Widget_PopupMenu_Large = 0x7f0b000e;
        public static final int TextAppearance_AppCompat_Light_Widget_PopupMenu_Small = 0x7f0b000f;
        public static final int TextAppearance_AppCompat_SearchResult_Subtitle = 0x7f0b0010;
        public static final int TextAppearance_AppCompat_SearchResult_Title = 0x7f0b0011;
        public static final int TextAppearance_AppCompat_Widget_ActionBar_Menu = 0x7f0b0012;
        public static final int TextAppearance_AppCompat_Widget_ActionBar_Subtitle = 0x7f0b0013;
        public static final int TextAppearance_AppCompat_Widget_ActionBar_Subtitle_Inverse = 0x7f0b0014;
        public static final int TextAppearance_AppCompat_Widget_ActionBar_Title = 0x7f0b0015;
        public static final int TextAppearance_AppCompat_Widget_ActionBar_Title_Inverse = 0x7f0b0016;
        public static final int TextAppearance_AppCompat_Widget_ActionMode_Subtitle = 0x7f0b0017;
        public static final int TextAppearance_AppCompat_Widget_ActionMode_Subtitle_Inverse = 0x7f0b0018;
        public static final int TextAppearance_AppCompat_Widget_ActionMode_Title = 0x7f0b0019;
        public static final int TextAppearance_AppCompat_Widget_ActionMode_Title_Inverse = 0x7f0b001a;
        public static final int TextAppearance_AppCompat_Widget_Base_ActionBar_Menu = 0x7f0b001b;
        public static final int TextAppearance_AppCompat_Widget_Base_ActionBar_Subtitle = 0x7f0b001c;
        public static final int TextAppearance_AppCompat_Widget_Base_ActionBar_Subtitle_Inverse = 0x7f0b001d;
        public static final int TextAppearance_AppCompat_Widget_Base_ActionBar_Title = 0x7f0b001e;
        public static final int TextAppearance_AppCompat_Widget_Base_ActionBar_Title_Inverse = 0x7f0b001f;
        public static final int TextAppearance_AppCompat_Widget_Base_ActionMode_Subtitle = 0x7f0b0020;
        public static final int TextAppearance_AppCompat_Widget_Base_ActionMode_Subtitle_Inverse = 0x7f0b0021;
        public static final int TextAppearance_AppCompat_Widget_Base_ActionMode_Title = 0x7f0b0022;
        public static final int TextAppearance_AppCompat_Widget_Base_ActionMode_Title_Inverse = 0x7f0b0023;
        public static final int TextAppearance_AppCompat_Widget_Base_DropDownItem = 0x7f0b0024;
        public static final int TextAppearance_AppCompat_Widget_DropDownItem = 0x7f0b0025;
        public static final int TextAppearance_AppCompat_Widget_PopupMenu_Large = 0x7f0b0026;
        public static final int TextAppearance_AppCompat_Widget_PopupMenu_Small = 0x7f0b0027;
        public static final int TextAppearance_Widget_AppCompat_Base_ExpandedMenu_Item = 0x7f0b0028;
        public static final int TextAppearance_Widget_AppCompat_ExpandedMenu_Item = 0x7f0b0029;
        public static final int Theme_AppCompat = 0x7f0b002a;
        public static final int Theme_AppCompat_Base_CompactMenu = 0x7f0b002b;
        public static final int Theme_AppCompat_Base_CompactMenu_Dialog = 0x7f0b002c;
        public static final int Theme_AppCompat_CompactMenu = 0x7f0b002d;
        public static final int Theme_AppCompat_CompactMenu_Dialog = 0x7f0b002e;
        public static final int Theme_AppCompat_DialogWhenLarge = 0x7f0b002f;
        public static final int Theme_AppCompat_Light = 0x7f0b0030;
        public static final int Theme_AppCompat_Light_DarkActionBar = 0x7f0b0031;
        public static final int Theme_AppCompat_Light_DialogWhenLarge = 0x7f0b0032;
        public static final int Theme_Base = 0x7f0b0033;
        public static final int Theme_Base_AppCompat = 0x7f0b0034;
        public static final int Theme_Base_AppCompat_DialogWhenLarge = 0x7f0b0037;
        public static final int Theme_Base_AppCompat_DialogWhenLarge_Base = 0x7f0b008a;
        public static final int Theme_Base_AppCompat_Dialog_FixedSize = 0x7f0b0035;
        public static final int Theme_Base_AppCompat_Dialog_Light_FixedSize = 0x7f0b0036;
        public static final int Theme_Base_AppCompat_Light = 0x7f0b0038;
        public static final int Theme_Base_AppCompat_Light_DarkActionBar = 0x7f0b0039;
        public static final int Theme_Base_AppCompat_Light_DialogWhenLarge = 0x7f0b003a;
        public static final int Theme_Base_AppCompat_Light_DialogWhenLarge_Base = 0x7f0b008b;
        public static final int Theme_Base_Light = 0x7f0b003b;
        public static final int Widget_AppCompat_ActionBar = 0x7f0b003c;
        public static final int Widget_AppCompat_ActionBar_Solid = 0x7f0b003d;
        public static final int Widget_AppCompat_ActionBar_TabBar = 0x7f0b003e;
        public static final int Widget_AppCompat_ActionBar_TabText = 0x7f0b003f;
        public static final int Widget_AppCompat_ActionBar_TabView = 0x7f0b0040;
        public static final int Widget_AppCompat_ActionButton = 0x7f0b0041;
        public static final int Widget_AppCompat_ActionButton_CloseMode = 0x7f0b0042;
        public static final int Widget_AppCompat_ActionButton_Overflow = 0x7f0b0043;
        public static final int Widget_AppCompat_ActionMode = 0x7f0b0044;
        public static final int Widget_AppCompat_ActivityChooserView = 0x7f0b0045;
        public static final int Widget_AppCompat_AutoCompleteTextView = 0x7f0b0046;
        public static final int Widget_AppCompat_Base_ActionBar = 0x7f0b0047;
        public static final int Widget_AppCompat_Base_ActionBar_Solid = 0x7f0b0048;
        public static final int Widget_AppCompat_Base_ActionBar_TabBar = 0x7f0b0049;
        public static final int Widget_AppCompat_Base_ActionBar_TabText = 0x7f0b004a;
        public static final int Widget_AppCompat_Base_ActionBar_TabView = 0x7f0b004b;
        public static final int Widget_AppCompat_Base_ActionButton = 0x7f0b004c;
        public static final int Widget_AppCompat_Base_ActionButton_CloseMode = 0x7f0b004d;
        public static final int Widget_AppCompat_Base_ActionButton_Overflow = 0x7f0b004e;
        public static final int Widget_AppCompat_Base_ActionMode = 0x7f0b004f;
        public static final int Widget_AppCompat_Base_ActivityChooserView = 0x7f0b0050;
        public static final int Widget_AppCompat_Base_AutoCompleteTextView = 0x7f0b0051;
        public static final int Widget_AppCompat_Base_DropDownItem_Spinner = 0x7f0b0052;
        public static final int Widget_AppCompat_Base_ListPopupWindow = 0x7f0b0053;
        public static final int Widget_AppCompat_Base_ListView_DropDown = 0x7f0b0054;
        public static final int Widget_AppCompat_Base_ListView_Menu = 0x7f0b0055;
        public static final int Widget_AppCompat_Base_PopupMenu = 0x7f0b0056;
        public static final int Widget_AppCompat_Base_ProgressBar = 0x7f0b0057;
        public static final int Widget_AppCompat_Base_ProgressBar_Horizontal = 0x7f0b0058;
        public static final int Widget_AppCompat_Base_Spinner = 0x7f0b0059;
        public static final int Widget_AppCompat_DropDownItem_Spinner = 0x7f0b005a;
        public static final int Widget_AppCompat_Light_ActionBar = 0x7f0b005b;
        public static final int Widget_AppCompat_Light_ActionBar_Solid = 0x7f0b005c;
        public static final int Widget_AppCompat_Light_ActionBar_Solid_Inverse = 0x7f0b005d;
        public static final int Widget_AppCompat_Light_ActionBar_TabBar = 0x7f0b005e;
        public static final int Widget_AppCompat_Light_ActionBar_TabBar_Inverse = 0x7f0b005f;
        public static final int Widget_AppCompat_Light_ActionBar_TabText = 0x7f0b0060;
        public static final int Widget_AppCompat_Light_ActionBar_TabText_Inverse = 0x7f0b0061;
        public static final int Widget_AppCompat_Light_ActionBar_TabView = 0x7f0b0062;
        public static final int Widget_AppCompat_Light_ActionBar_TabView_Inverse = 0x7f0b0063;
        public static final int Widget_AppCompat_Light_ActionButton = 0x7f0b0064;
        public static final int Widget_AppCompat_Light_ActionButton_CloseMode = 0x7f0b0065;
        public static final int Widget_AppCompat_Light_ActionButton_Overflow = 0x7f0b0066;
        public static final int Widget_AppCompat_Light_ActionMode_Inverse = 0x7f0b0067;
        public static final int Widget_AppCompat_Light_ActivityChooserView = 0x7f0b0068;
        public static final int Widget_AppCompat_Light_AutoCompleteTextView = 0x7f0b0069;
        public static final int Widget_AppCompat_Light_Base_ActionBar = 0x7f0b006a;
        public static final int Widget_AppCompat_Light_Base_ActionBar_Solid = 0x7f0b006b;
        public static final int Widget_AppCompat_Light_Base_ActionBar_Solid_Inverse = 0x7f0b006c;
        public static final int Widget_AppCompat_Light_Base_ActionBar_TabBar = 0x7f0b006d;
        public static final int Widget_AppCompat_Light_Base_ActionBar_TabBar_Inverse = 0x7f0b006e;
        public static final int Widget_AppCompat_Light_Base_ActionBar_TabText = 0x7f0b006f;
        public static final int Widget_AppCompat_Light_Base_ActionBar_TabText_Inverse = 0x7f0b0070;
        public static final int Widget_AppCompat_Light_Base_ActionBar_TabView = 0x7f0b0071;
        public static final int Widget_AppCompat_Light_Base_ActionBar_TabView_Inverse = 0x7f0b0072;
        public static final int Widget_AppCompat_Light_Base_ActionButton = 0x7f0b0073;
        public static final int Widget_AppCompat_Light_Base_ActionButton_CloseMode = 0x7f0b0074;
        public static final int Widget_AppCompat_Light_Base_ActionButton_Overflow = 0x7f0b0075;
        public static final int Widget_AppCompat_Light_Base_ActionMode_Inverse = 0x7f0b0076;
        public static final int Widget_AppCompat_Light_Base_ActivityChooserView = 0x7f0b0077;
        public static final int Widget_AppCompat_Light_Base_AutoCompleteTextView = 0x7f0b0078;
        public static final int Widget_AppCompat_Light_Base_DropDownItem_Spinner = 0x7f0b0079;
        public static final int Widget_AppCompat_Light_Base_ListPopupWindow = 0x7f0b007a;
        public static final int Widget_AppCompat_Light_Base_ListView_DropDown = 0x7f0b007b;
        public static final int Widget_AppCompat_Light_Base_PopupMenu = 0x7f0b007c;
        public static final int Widget_AppCompat_Light_Base_Spinner = 0x7f0b007d;
        public static final int Widget_AppCompat_Light_DropDownItem_Spinner = 0x7f0b007e;
        public static final int Widget_AppCompat_Light_ListPopupWindow = 0x7f0b007f;
        public static final int Widget_AppCompat_Light_ListView_DropDown = 0x7f0b0080;
        public static final int Widget_AppCompat_Light_PopupMenu = 0x7f0b0081;
        public static final int Widget_AppCompat_Light_Spinner_DropDown_ActionBar = 0x7f0b0082;
        public static final int Widget_AppCompat_ListPopupWindow = 0x7f0b0083;
        public static final int Widget_AppCompat_ListView_DropDown = 0x7f0b0084;
        public static final int Widget_AppCompat_ListView_Menu = 0x7f0b0085;
        public static final int Widget_AppCompat_PopupMenu = 0x7f0b0086;
        public static final int Widget_AppCompat_ProgressBar = 0x7f0b0087;
        public static final int Widget_AppCompat_ProgressBar_Horizontal = 0x7f0b0088;
        public static final int Widget_AppCompat_Spinner_DropDown_ActionBar = 0x7f0b0089;

        public style()
        {
        }
    }

    public static final class styleable
    {

        public static final int ActionBar[] = {
            0x7f010020, 0x7f01003e, 0x7f01003f, 0x7f010040, 0x7f010041, 0x7f010042, 0x7f010043, 0x7f010044, 0x7f010045, 0x7f010046, 
            0x7f010047, 0x7f010048, 0x7f010049, 0x7f01004a, 0x7f01004b, 0x7f01004c, 0x7f01004d, 0x7f01004e, 0x7f01004f
        };
        public static final int ActionBarLayout[] = {
            0x10100b3
        };
        public static final int ActionBarLayout_android_layout_gravity = 0;
        public static final int ActionBarWindow[] = {
            0x7f010050, 0x7f010051, 0x7f010052, 0x7f010053, 0x7f010054, 0x7f010055, 0x7f010056
        };
        public static final int ActionBarWindow_windowActionBar = 0;
        public static final int ActionBarWindow_windowActionBarOverlay = 1;
        public static final int ActionBarWindow_windowFixedHeightMajor = 6;
        public static final int ActionBarWindow_windowFixedHeightMinor = 4;
        public static final int ActionBarWindow_windowFixedWidthMajor = 3;
        public static final int ActionBarWindow_windowFixedWidthMinor = 5;
        public static final int ActionBarWindow_windowSplitActionBar = 2;
        public static final int ActionBar_background = 10;
        public static final int ActionBar_backgroundSplit = 12;
        public static final int ActionBar_backgroundStacked = 11;
        public static final int ActionBar_customNavigationLayout = 13;
        public static final int ActionBar_displayOptions = 3;
        public static final int ActionBar_divider = 9;
        public static final int ActionBar_height = 0;
        public static final int ActionBar_homeLayout = 14;
        public static final int ActionBar_icon = 7;
        public static final int ActionBar_indeterminateProgressStyle = 16;
        public static final int ActionBar_itemPadding = 18;
        public static final int ActionBar_logo = 8;
        public static final int ActionBar_navigationMode = 2;
        public static final int ActionBar_progressBarPadding = 17;
        public static final int ActionBar_progressBarStyle = 15;
        public static final int ActionBar_subtitle = 4;
        public static final int ActionBar_subtitleTextStyle = 6;
        public static final int ActionBar_title = 1;
        public static final int ActionBar_titleTextStyle = 5;
        public static final int ActionMenuItemView[] = {
            0x101013f
        };
        public static final int ActionMenuItemView_android_minWidth = 0;
        public static final int ActionMenuView[] = new int[0];
        public static final int ActionMode[] = {
            0x7f010020, 0x7f010042, 0x7f010043, 0x7f010047, 0x7f010049
        };
        public static final int ActionMode_background = 3;
        public static final int ActionMode_backgroundSplit = 4;
        public static final int ActionMode_height = 0;
        public static final int ActionMode_subtitleTextStyle = 2;
        public static final int ActionMode_titleTextStyle = 1;
        public static final int ActivityChooserView[] = {
            0x7f010057, 0x7f010058
        };
        public static final int ActivityChooserView_expandActivityOverflowButtonDrawable = 1;
        public static final int ActivityChooserView_initialActivityCount = 0;
        public static final int CompatTextView[] = {
            0x7f010059
        };
        public static final int CompatTextView_textAllCaps = 0;
        public static final int LinearLayoutICS[] = {
            0x7f010046, 0x7f01005a, 0x7f01005b
        };
        public static final int LinearLayoutICS_divider = 0;
        public static final int LinearLayoutICS_dividerPadding = 2;
        public static final int LinearLayoutICS_showDividers = 1;
        public static final int MenuGroup[] = {
            0x101000e, 0x10100d0, 0x1010194, 0x10101de, 0x10101df, 0x10101e0
        };
        public static final int MenuGroup_android_checkableBehavior = 5;
        public static final int MenuGroup_android_enabled = 0;
        public static final int MenuGroup_android_id = 1;
        public static final int MenuGroup_android_menuCategory = 3;
        public static final int MenuGroup_android_orderInCategory = 4;
        public static final int MenuGroup_android_visible = 2;
        public static final int MenuItem[] = {
            0x1010002, 0x101000e, 0x10100d0, 0x1010106, 0x1010194, 0x10101de, 0x10101df, 0x10101e1, 0x10101e2, 0x10101e3, 
            0x10101e4, 0x10101e5, 0x101026f, 0x7f01005c, 0x7f01005d, 0x7f01005e, 0x7f01005f
        };
        public static final int MenuItem_actionLayout = 14;
        public static final int MenuItem_actionProviderClass = 16;
        public static final int MenuItem_actionViewClass = 15;
        public static final int MenuItem_android_alphabeticShortcut = 9;
        public static final int MenuItem_android_checkable = 11;
        public static final int MenuItem_android_checked = 3;
        public static final int MenuItem_android_enabled = 1;
        public static final int MenuItem_android_icon = 0;
        public static final int MenuItem_android_id = 2;
        public static final int MenuItem_android_menuCategory = 5;
        public static final int MenuItem_android_numericShortcut = 10;
        public static final int MenuItem_android_onClick = 12;
        public static final int MenuItem_android_orderInCategory = 6;
        public static final int MenuItem_android_title = 7;
        public static final int MenuItem_android_titleCondensed = 8;
        public static final int MenuItem_android_visible = 4;
        public static final int MenuItem_showAsAction = 13;
        public static final int MenuView[] = {
            0x10100ae, 0x101012c, 0x101012d, 0x101012e, 0x101012f, 0x1010130, 0x1010131, 0x1010438
        };
        public static final int MenuView_android_headerBackground = 4;
        public static final int MenuView_android_horizontalDivider = 2;
        public static final int MenuView_android_itemBackground = 5;
        public static final int MenuView_android_itemIconDisabledAlpha = 6;
        public static final int MenuView_android_itemTextAppearance = 1;
        public static final int MenuView_android_preserveIconSpacing = 7;
        public static final int MenuView_android_verticalDivider = 3;
        public static final int MenuView_android_windowAnimationStyle = 0;
        public static final int SearchView[] = {
            0x101011f, 0x1010220, 0x1010264, 0x7f010060, 0x7f010061
        };
        public static final int SearchView_android_imeOptions = 2;
        public static final int SearchView_android_inputType = 1;
        public static final int SearchView_android_maxWidth = 0;
        public static final int SearchView_iconifiedByDefault = 3;
        public static final int SearchView_queryHint = 4;
        public static final int Spinner[] = {
            0x10100af, 0x1010175, 0x1010176, 0x1010262, 0x10102ac, 0x10102ad, 0x7f010062, 0x7f010063, 0x7f010064, 0x7f010065
        };
        public static final int Spinner_android_dropDownHorizontalOffset = 4;
        public static final int Spinner_android_dropDownSelector = 1;
        public static final int Spinner_android_dropDownVerticalOffset = 5;
        public static final int Spinner_android_dropDownWidth = 3;
        public static final int Spinner_android_gravity = 0;
        public static final int Spinner_android_popupBackground = 2;
        public static final int Spinner_disableChildrenWhenDisabled = 9;
        public static final int Spinner_popupPromptView = 8;
        public static final int Spinner_prompt = 6;
        public static final int Spinner_spinnerMode = 7;
        public static final int Theme[] = {
            0x7f010066, 0x7f010067, 0x7f010068, 0x7f010069, 0x7f01006a, 0x7f01006b
        };
        public static final int Theme_actionDropDownStyle = 0;
        public static final int Theme_dropdownListPreferredItemHeight = 1;
        public static final int Theme_listChoiceBackgroundIndicator = 5;
        public static final int Theme_panelMenuListTheme = 4;
        public static final int Theme_panelMenuListWidth = 3;
        public static final int Theme_popupMenuStyle = 2;
        public static final int View[] = {
            0x10100da, 0x7f01006c, 0x7f01006d
        };
        public static final int View_android_focusable = 0;
        public static final int View_paddingEnd = 2;
        public static final int View_paddingStart = 1;


        public styleable()
        {
        }
    }


    public R()
    {
    }
}
