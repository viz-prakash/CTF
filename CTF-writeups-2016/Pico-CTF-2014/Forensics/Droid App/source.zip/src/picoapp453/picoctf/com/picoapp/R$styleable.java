// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package picoapp453.picoctf.com.picoapp;


// Referenced classes of package picoapp453.picoctf.com.picoapp:
//            R

public static final class 
{

    public static final int ActionBar[] = {
        0x7f010020, 0x7f01003e, 0x7f01003f, 0x7f010040, 0x7f010041, 0x7f010042, 0x7f010043, 0x7f010044, 0x7f010045, 0x7f010046, 
        0x7f010047, 0x7f010048, 0x7f010049, 0x7f01004a, 0x7f01004b, 0x7f01004c, 0x7f01004d, 0x7f01004e, 0x7f01004f
    };
    public static final int ActionBarLayout[] = {
        0x10100b3
    };
    public static final int ActionBarLayout_android_layout_gravity = 0;
    public static final int ActionBarWindow[] = {
        0x7f010050, 0x7f010051, 0x7f010052, 0x7f010053, 0x7f010054, 0x7f010055, 0x7f010056
    };
    public static final int ActionBarWindow_windowActionBar = 0;
    public static final int ActionBarWindow_windowActionBarOverlay = 1;
    public static final int ActionBarWindow_windowFixedHeightMajor = 6;
    public static final int ActionBarWindow_windowFixedHeightMinor = 4;
    public static final int ActionBarWindow_windowFixedWidthMajor = 3;
    public static final int ActionBarWindow_windowFixedWidthMinor = 5;
    public static final int ActionBarWindow_windowSplitActionBar = 2;
    public static final int ActionBar_background = 10;
    public static final int ActionBar_backgroundSplit = 12;
    public static final int ActionBar_backgroundStacked = 11;
    public static final int ActionBar_customNavigationLayout = 13;
    public static final int ActionBar_displayOptions = 3;
    public static final int ActionBar_divider = 9;
    public static final int ActionBar_height = 0;
    public static final int ActionBar_homeLayout = 14;
    public static final int ActionBar_icon = 7;
    public static final int ActionBar_indeterminateProgressStyle = 16;
    public static final int ActionBar_itemPadding = 18;
    public static final int ActionBar_logo = 8;
    public static final int ActionBar_navigationMode = 2;
    public static final int ActionBar_progressBarPadding = 17;
    public static final int ActionBar_progressBarStyle = 15;
    public static final int ActionBar_subtitle = 4;
    public static final int ActionBar_subtitleTextStyle = 6;
    public static final int ActionBar_title = 1;
    public static final int ActionBar_titleTextStyle = 5;
    public static final int ActionMenuItemView[] = {
        0x101013f
    };
    public static final int ActionMenuItemView_android_minWidth = 0;
    public static final int ActionMenuView[] = new int[0];
    public static final int ActionMode[] = {
        0x7f010020, 0x7f010042, 0x7f010043, 0x7f010047, 0x7f010049
    };
    public static final int ActionMode_background = 3;
    public static final int ActionMode_backgroundSplit = 4;
    public static final int ActionMode_height = 0;
    public static final int ActionMode_subtitleTextStyle = 2;
    public static final int ActionMode_titleTextStyle = 1;
    public static final int ActivityChooserView[] = {
        0x7f010057, 0x7f010058
    };
    public static final int ActivityChooserView_expandActivityOverflowButtonDrawable = 1;
    public static final int ActivityChooserView_initialActivityCount = 0;
    public static final int CompatTextView[] = {
        0x7f010059
    };
    public static final int CompatTextView_textAllCaps = 0;
    public static final int LinearLayoutICS[] = {
        0x7f010046, 0x7f01005a, 0x7f01005b
    };
    public static final int LinearLayoutICS_divider = 0;
    public static final int LinearLayoutICS_dividerPadding = 2;
    public static final int LinearLayoutICS_showDividers = 1;
    public static final int MenuGroup[] = {
        0x101000e, 0x10100d0, 0x1010194, 0x10101de, 0x10101df, 0x10101e0
    };
    public static final int MenuGroup_android_checkableBehavior = 5;
    public static final int MenuGroup_android_enabled = 0;
    public static final int MenuGroup_android_id = 1;
    public static final int MenuGroup_android_menuCategory = 3;
    public static final int MenuGroup_android_orderInCategory = 4;
    public static final int MenuGroup_android_visible = 2;
    public static final int MenuItem[] = {
        0x1010002, 0x101000e, 0x10100d0, 0x1010106, 0x1010194, 0x10101de, 0x10101df, 0x10101e1, 0x10101e2, 0x10101e3, 
        0x10101e4, 0x10101e5, 0x101026f, 0x7f01005c, 0x7f01005d, 0x7f01005e, 0x7f01005f
    };
    public static final int MenuItem_actionLayout = 14;
    public static final int MenuItem_actionProviderClass = 16;
    public static final int MenuItem_actionViewClass = 15;
    public static final int MenuItem_android_alphabeticShortcut = 9;
    public static final int MenuItem_android_checkable = 11;
    public static final int MenuItem_android_checked = 3;
    public static final int MenuItem_android_enabled = 1;
    public static final int MenuItem_android_icon = 0;
    public static final int MenuItem_android_id = 2;
    public static final int MenuItem_android_menuCategory = 5;
    public static final int MenuItem_android_numericShortcut = 10;
    public static final int MenuItem_android_onClick = 12;
    public static final int MenuItem_android_orderInCategory = 6;
    public static final int MenuItem_android_title = 7;
    public static final int MenuItem_android_titleCondensed = 8;
    public static final int MenuItem_android_visible = 4;
    public static final int MenuItem_showAsAction = 13;
    public static final int MenuView[] = {
        0x10100ae, 0x101012c, 0x101012d, 0x101012e, 0x101012f, 0x1010130, 0x1010131, 0x1010438
    };
    public static final int MenuView_android_headerBackground = 4;
    public static final int MenuView_android_horizontalDivider = 2;
    public static final int MenuView_android_itemBackground = 5;
    public static final int MenuView_android_itemIconDisabledAlpha = 6;
    public static final int MenuView_android_itemTextAppearance = 1;
    public static final int MenuView_android_preserveIconSpacing = 7;
    public static final int MenuView_android_verticalDivider = 3;
    public static final int MenuView_android_windowAnimationStyle = 0;
    public static final int SearchView[] = {
        0x101011f, 0x1010220, 0x1010264, 0x7f010060, 0x7f010061
    };
    public static final int SearchView_android_imeOptions = 2;
    public static final int SearchView_android_inputType = 1;
    public static final int SearchView_android_maxWidth = 0;
    public static final int SearchView_iconifiedByDefault = 3;
    public static final int SearchView_queryHint = 4;
    public static final int Spinner[] = {
        0x10100af, 0x1010175, 0x1010176, 0x1010262, 0x10102ac, 0x10102ad, 0x7f010062, 0x7f010063, 0x7f010064, 0x7f010065
    };
    public static final int Spinner_android_dropDownHorizontalOffset = 4;
    public static final int Spinner_android_dropDownSelector = 1;
    public static final int Spinner_android_dropDownVerticalOffset = 5;
    public static final int Spinner_android_dropDownWidth = 3;
    public static final int Spinner_android_gravity = 0;
    public static final int Spinner_android_popupBackground = 2;
    public static final int Spinner_disableChildrenWhenDisabled = 9;
    public static final int Spinner_popupPromptView = 8;
    public static final int Spinner_prompt = 6;
    public static final int Spinner_spinnerMode = 7;
    public static final int Theme[] = {
        0x7f010066, 0x7f010067, 0x7f010068, 0x7f010069, 0x7f01006a, 0x7f01006b
    };
    public static final int Theme_actionDropDownStyle = 0;
    public static final int Theme_dropdownListPreferredItemHeight = 1;
    public static final int Theme_listChoiceBackgroundIndicator = 5;
    public static final int Theme_panelMenuListTheme = 4;
    public static final int Theme_panelMenuListWidth = 3;
    public static final int Theme_popupMenuStyle = 2;
    public static final int View[] = {
        0x10100da, 0x7f01006c, 0x7f01006d
    };
    public static final int View_android_focusable = 0;
    public static final int View_paddingEnd = 2;
    public static final int View_paddingStart = 1;


    public ()
    {
    }
}
