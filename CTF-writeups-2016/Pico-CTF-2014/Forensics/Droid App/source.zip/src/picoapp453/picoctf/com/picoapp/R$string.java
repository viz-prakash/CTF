// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package picoapp453.picoctf.com.picoapp;


// Referenced classes of package picoapp453.picoctf.com.picoapp:
//            R

public static final class 
{

    public static final int abc_action_bar_home_description = 0x7f0a0000;
    public static final int abc_action_bar_up_description = 0x7f0a0001;
    public static final int abc_action_menu_overflow_description = 0x7f0a0002;
    public static final int abc_action_mode_done = 0x7f0a0003;
    public static final int abc_activity_chooser_view_see_all = 0x7f0a0004;
    public static final int abc_activitychooserview_choose_application = 0x7f0a0005;
    public static final int abc_searchview_description_clear = 0x7f0a0006;
    public static final int abc_searchview_description_query = 0x7f0a0007;
    public static final int abc_searchview_description_search = 0x7f0a0008;
    public static final int abc_searchview_description_submit = 0x7f0a0009;
    public static final int abc_searchview_description_voice = 0x7f0a000a;
    public static final int abc_shareactionprovider_share_with = 0x7f0a000b;
    public static final int abc_shareactionprovider_share_with_application = 0x7f0a000c;
    public static final int action_settings = 0x7f0a000d;
    public static final int app_name = 0x7f0a000e;
    public static final int button_name = 0x7f0a000f;

    public ()
    {
    }
}
