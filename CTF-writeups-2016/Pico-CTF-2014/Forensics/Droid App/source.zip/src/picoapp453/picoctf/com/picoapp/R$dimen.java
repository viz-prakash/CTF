// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package picoapp453.picoctf.com.picoapp;


// Referenced classes of package picoapp453.picoctf.com.picoapp:
//            R

public static final class 
{

    public static final int abc_action_bar_default_height = 0x7f080000;
    public static final int abc_action_bar_icon_vertical_padding = 0x7f080001;
    public static final int abc_action_bar_progress_bar_size = 0x7f080002;
    public static final int abc_action_bar_stacked_max_height = 0x7f080003;
    public static final int abc_action_bar_stacked_tab_max_width = 0x7f080004;
    public static final int abc_action_bar_subtitle_bottom_margin = 0x7f080005;
    public static final int abc_action_bar_subtitle_text_size = 0x7f080006;
    public static final int abc_action_bar_subtitle_top_margin = 0x7f080007;
    public static final int abc_action_bar_title_text_size = 0x7f080008;
    public static final int abc_action_button_min_width = 0x7f080009;
    public static final int abc_config_prefDialogWidth = 0x7f08000a;
    public static final int abc_dropdownitem_icon_width = 0x7f08000b;
    public static final int abc_dropdownitem_text_padding_left = 0x7f08000c;
    public static final int abc_dropdownitem_text_padding_right = 0x7f08000d;
    public static final int abc_panel_menu_list_width = 0x7f08000e;
    public static final int abc_search_view_preferred_width = 0x7f08000f;
    public static final int abc_search_view_text_min_width = 0x7f080010;
    public static final int activity_horizontal_margin = 0x7f080011;
    public static final int activity_vertical_margin = 0x7f080012;
    public static final int dialog_fixed_height_major = 0x7f080013;
    public static final int dialog_fixed_height_minor = 0x7f080014;
    public static final int dialog_fixed_width_major = 0x7f080015;
    public static final int dialog_fixed_width_minor = 0x7f080016;

    public ()
    {
    }
}
