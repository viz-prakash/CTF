// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package picoapp453.picoctf.com.picoapp;


// Referenced classes of package picoapp453.picoctf.com.picoapp:
//            R

public static final class 
{

    public static final int actionBarDivider = 0x7f010000;
    public static final int actionBarItemBackground = 0x7f010001;
    public static final int actionBarSize = 0x7f010002;
    public static final int actionBarSplitStyle = 0x7f010003;
    public static final int actionBarStyle = 0x7f010004;
    public static final int actionBarTabBarStyle = 0x7f010005;
    public static final int actionBarTabStyle = 0x7f010006;
    public static final int actionBarTabTextStyle = 0x7f010007;
    public static final int actionBarWidgetTheme = 0x7f010008;
    public static final int actionButtonStyle = 0x7f010009;
    public static final int actionDropDownStyle = 0x7f010066;
    public static final int actionLayout = 0x7f01005d;
    public static final int actionMenuTextAppearance = 0x7f01000a;
    public static final int actionMenuTextColor = 0x7f01000b;
    public static final int actionModeBackground = 0x7f01000c;
    public static final int actionModeCloseButtonStyle = 0x7f01000d;
    public static final int actionModeCloseDrawable = 0x7f01000e;
    public static final int actionModeCopyDrawable = 0x7f01000f;
    public static final int actionModeCutDrawable = 0x7f010010;
    public static final int actionModeFindDrawable = 0x7f010011;
    public static final int actionModePasteDrawable = 0x7f010012;
    public static final int actionModePopupWindowStyle = 0x7f010013;
    public static final int actionModeSelectAllDrawable = 0x7f010014;
    public static final int actionModeShareDrawable = 0x7f010015;
    public static final int actionModeSplitBackground = 0x7f010016;
    public static final int actionModeStyle = 0x7f010017;
    public static final int actionModeWebSearchDrawable = 0x7f010018;
    public static final int actionOverflowButtonStyle = 0x7f010019;
    public static final int actionProviderClass = 0x7f01005f;
    public static final int actionViewClass = 0x7f01005e;
    public static final int activityChooserViewStyle = 0x7f01001a;
    public static final int background = 0x7f010047;
    public static final int backgroundSplit = 0x7f010049;
    public static final int backgroundStacked = 0x7f010048;
    public static final int buttonBarButtonStyle = 0x7f01001b;
    public static final int buttonBarStyle = 0x7f01001c;
    public static final int customNavigationLayout = 0x7f01004a;
    public static final int disableChildrenWhenDisabled = 0x7f010065;
    public static final int displayOptions = 0x7f010040;
    public static final int divider = 0x7f010046;
    public static final int dividerHorizontal = 0x7f01001d;
    public static final int dividerPadding = 0x7f01005b;
    public static final int dividerVertical = 0x7f01001e;
    public static final int dropDownListViewStyle = 0x7f01001f;
    public static final int dropdownListPreferredItemHeight = 0x7f010067;
    public static final int expandActivityOverflowButtonDrawable = 0x7f010058;
    public static final int height = 0x7f010020;
    public static final int homeAsUpIndicator = 0x7f010021;
    public static final int homeLayout = 0x7f01004b;
    public static final int icon = 0x7f010044;
    public static final int iconifiedByDefault = 0x7f010060;
    public static final int indeterminateProgressStyle = 0x7f01004d;
    public static final int initialActivityCount = 0x7f010057;
    public static final int isLightTheme = 0x7f010022;
    public static final int itemPadding = 0x7f01004f;
    public static final int listChoiceBackgroundIndicator = 0x7f01006b;
    public static final int listPopupWindowStyle = 0x7f010023;
    public static final int listPreferredItemHeight = 0x7f010024;
    public static final int listPreferredItemHeightLarge = 0x7f010025;
    public static final int listPreferredItemHeightSmall = 0x7f010026;
    public static final int listPreferredItemPaddingLeft = 0x7f010027;
    public static final int listPreferredItemPaddingRight = 0x7f010028;
    public static final int logo = 0x7f010045;
    public static final int navigationMode = 0x7f01003f;
    public static final int paddingEnd = 0x7f01006d;
    public static final int paddingStart = 0x7f01006c;
    public static final int panelMenuListTheme = 0x7f01006a;
    public static final int panelMenuListWidth = 0x7f010069;
    public static final int popupMenuStyle = 0x7f010068;
    public static final int popupPromptView = 0x7f010064;
    public static final int progressBarPadding = 0x7f01004e;
    public static final int progressBarStyle = 0x7f01004c;
    public static final int prompt = 0x7f010062;
    public static final int queryHint = 0x7f010061;
    public static final int searchDropdownBackground = 0x7f010029;
    public static final int searchResultListItemHeight = 0x7f01002a;
    public static final int searchViewAutoCompleteTextView = 0x7f01002b;
    public static final int searchViewCloseIcon = 0x7f01002c;
    public static final int searchViewEditQuery = 0x7f01002d;
    public static final int searchViewEditQueryBackground = 0x7f01002e;
    public static final int searchViewGoIcon = 0x7f01002f;
    public static final int searchViewSearchIcon = 0x7f010030;
    public static final int searchViewTextField = 0x7f010031;
    public static final int searchViewTextFieldRight = 0x7f010032;
    public static final int searchViewVoiceIcon = 0x7f010033;
    public static final int selectableItemBackground = 0x7f010034;
    public static final int showAsAction = 0x7f01005c;
    public static final int showDividers = 0x7f01005a;
    public static final int spinnerDropDownItemStyle = 0x7f010035;
    public static final int spinnerMode = 0x7f010063;
    public static final int spinnerStyle = 0x7f010036;
    public static final int subtitle = 0x7f010041;
    public static final int subtitleTextStyle = 0x7f010043;
    public static final int textAllCaps = 0x7f010059;
    public static final int textAppearanceLargePopupMenu = 0x7f010037;
    public static final int textAppearanceListItem = 0x7f010038;
    public static final int textAppearanceListItemSmall = 0x7f010039;
    public static final int textAppearanceSearchResultSubtitle = 0x7f01003a;
    public static final int textAppearanceSearchResultTitle = 0x7f01003b;
    public static final int textAppearanceSmallPopupMenu = 0x7f01003c;
    public static final int textColorSearchUrl = 0x7f01003d;
    public static final int title = 0x7f01003e;
    public static final int titleTextStyle = 0x7f010042;
    public static final int windowActionBar = 0x7f010050;
    public static final int windowActionBarOverlay = 0x7f010051;
    public static final int windowFixedHeightMajor = 0x7f010056;
    public static final int windowFixedHeightMinor = 0x7f010054;
    public static final int windowFixedWidthMajor = 0x7f010053;
    public static final int windowFixedWidthMinor = 0x7f010055;
    public static final int windowSplitActionBar = 0x7f010052;

    public ()
    {
    }
}
